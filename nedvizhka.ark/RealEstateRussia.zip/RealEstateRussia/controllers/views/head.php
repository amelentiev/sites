<!-- ---------------------------------------------------------------------------------! -->
<!-- Site Developed by Progress Motion Digital & Web - https://progress-motion.com    ! -->
<!-- ---------------------------------------------------------------------------------! -->
<!DOCTYPE html>
<html lang="ru">
<head>
	<title>Доходная Недвижимость России | Главная</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="keywords" content="">
	<link rel="shortcut icon" href="">
	<!-- Bootstrap CSS-->
	<link rel="stylesheet" href="frameworks/bootstrap/css/bootstrap.min.css">
	<!-- Custom CSS -->
	<link rel="stylesheet" href="css/style.css">
</head>